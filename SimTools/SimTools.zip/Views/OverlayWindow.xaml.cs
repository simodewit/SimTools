﻿using System.Windows;

namespace SimTools.Views
{
    public partial class OverlayWindow : Window
    {
        public OverlayWindow()
        {
            InitializeComponent();
        }
    }
}
