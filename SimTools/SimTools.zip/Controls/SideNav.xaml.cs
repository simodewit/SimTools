﻿using System.Windows.Controls;

namespace SimTools.Controls
{
    public partial class SideNav : UserControl
    {
        public SideNav() => InitializeComponent();
    }
}